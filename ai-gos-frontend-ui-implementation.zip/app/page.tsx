import AIGosApp from '@/components/ai-gos-app'

export default function Page() {
  return <AIGosApp />
}
